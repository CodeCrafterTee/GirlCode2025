import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Shield, FileText, HelpCircle, DollarSign, ExternalLink, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

export function TermsFAQsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Terms & Policies</h1>
        <p className="text-gray-600 dark:text-gray-400">Everything you need to know about eWallet</p>
      </div>

      <Alert className="border-indigo-200 bg-indigo-50 dark:bg-indigo-950/20">
        <ExternalLink className="h-4 w-4" />
        <AlertTitle>Visit Our Website</AlertTitle>
        <AlertDescription className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
          <span>For more information about eWallet services, features, and updates</span>
          <Button variant="outline" size="sm" asChild>
            <a href="https://www.ewallet.co.za" target="_blank" rel="noopener noreferrer">
              www.ewallet.co.za
              <ExternalLink className="w-3 h-3 ml-2" />
            </a>
          </Button>
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="faqs" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="faqs">
            <HelpCircle className="w-4 h-4 mr-2" />
            FAQs
          </TabsTrigger>
          <TabsTrigger value="policies">
            <Shield className="w-4 h-4 mr-2" />
            Policies
          </TabsTrigger>
          <TabsTrigger value="fees">
            <DollarSign className="w-4 h-4 mr-2" />
            Fees
          </TabsTrigger>
          <TabsTrigger value="terms">
            <FileText className="w-4 h-4 mr-2" />
            Terms
          </TabsTrigger>
        </TabsList>

        {/* FAQs Tab */}
        <TabsContent value="faqs">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>Find answers to common questions</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="faq-1">
                  <AccordionTrigger>How do I create an account?</AccordionTrigger>
                  <AccordionContent>
                    Click "Register" on the login page. You'll need to provide personal information, upload a valid ID, take a selfie for verification, and create a secure password. The process takes about 5 minutes.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="faq-2">
                  <AccordionTrigger>Is my money safe?</AccordionTrigger>
                  <AccordionContent>
                    Yes. We use bank-level encryption and security measures. All accounts are covered by the South African Reserve Bank deposit insurance scheme up to R100,000. We employ multi-factor authentication and biometric verification.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="faq-3">
                  <AccordionTrigger>How do I add money to my account?</AccordionTrigger>
                  <AccordionContent>
                    You can add money via: Bank Transfer (EFT - free, 1-3 days), Instant EFT (R15, instant), Debit/Credit Card (2.5% fee, instant), Cash Deposit at Pick n Pay or Checkers (R20 fee), or Direct Deposit for salaries (free).
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="faq-4">
                  <AccordionTrigger>What are the transaction limits?</AccordionTrigger>
                  <AccordionContent>
                    Standard accounts: R20,000 daily, R200,000 monthly. Premium accounts: R100,000 daily, R500,000 monthly. You can request limit increases by contacting support.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="faq-5">
                  <AccordionTrigger>How do I transfer money?</AccordionTrigger>
                  <AccordionContent>
                    Go to the Accounts page and click "Send". Enter recipient details, amount, and confirm. Transfers to other eWallet users are instant and free. External EFT transfers cost R5 and process within 24 hours.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="faq-6">
                  <AccordionTrigger>What interest do I earn on savings?</AccordionTrigger>
                  <AccordionContent>
                    Savings accounts offer 3.5% APY. Interest is calculated daily and credited monthly. No minimum balance required and no monthly fees.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="faq-7">
                  <AccordionTrigger>How do I contact support?</AccordionTrigger>
                  <AccordionContent>
                    Visit the Support page to chat with our AI assistant or request a live agent. You can also email support@ewallet.co.za or call 0861 392 5538 (24/7).
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="faq-8">
                  <AccordionTrigger>What fees does eWallet charge?</AccordionTrigger>
                  <AccordionContent>
                    Basic account maintenance is free. Internal transfers are free. External EFT costs R5. ATM withdrawals: 4 free per month, then R15 each. See the Fees tab for complete pricing.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Policies Tab */}
        <TabsContent value="policies" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Payment & Deposit Policies</CardTitle>
              <CardDescription>How we handle your money</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Deposit Methods</h4>
                <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400 list-disc list-inside">
                  <li>Bank Transfer (EFT): Free, 1-3 business days</li>
                  <li>Instant EFT: R15 fee, instant</li>
                  <li>Debit/Credit Card: 2.5% fee, instant</li>
                  <li>Cash at Pick n Pay/Checkers: R20 fee</li>
                  <li>Direct Deposit (salaries): Free</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Deposit Limits</h4>
                <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400 list-disc list-inside">
                  <li>Standard: R50,000 daily, R500,000 monthly</li>
                  <li>Premium: R200,000 daily, R2M monthly</li>
                  <li>Verification required for deposits over R25,000</li>
                  <li>All deposits insured up to R100,000 by SARB</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Withdrawal Options</h4>
                <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400 list-disc list-inside">
                  <li>Bank Transfer: Free, 1-2 business days</li>
                  <li>Instant Withdrawal: 1% fee (min R10), up to R5,000</li>
                  <li>ATM: 4 free per month, R15 thereafter</li>
                  <li>Large withdrawals (&gt;R50,000) may require 24hr verification</li>
                </ul>
              </div>
              <Alert className="border-yellow-200 bg-yellow-50 dark:bg-yellow-950/20">
                <AlertCircle className="h-4 w-4 text-yellow-600" />
                <AlertTitle className="text-yellow-900 dark:text-yellow-100">AML Compliance</AlertTitle>
                <AlertDescription className="text-sm text-yellow-800 dark:text-yellow-200">
                  We're required by law to verify large deposits and report suspicious transactions to the Financial Intelligence Centre (FIC).
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Security & Privacy</CardTitle>
              <CardDescription>How we protect your information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-medium mb-2">Security Measures</h4>
                <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400 list-disc list-inside">
                  <li>256-bit SSL/TLS encryption for all data</li>
                  <li>Two-factor authentication for transactions over R5,000</li>
                  <li>Biometric verification (fingerprint, facial recognition)</li>
                  <li>24/7 fraud detection and monitoring</li>
                  <li>Instant account freeze via app</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Privacy Protection</h4>
                <ul className="text-sm space-y-1 text-gray-600 dark:text-gray-400 list-disc list-inside">
                  <li>Fully compliant with Protection of Personal Information Act (POPIA)</li>
                  <li>We never sell your data to third parties</li>
                  <li>Right to access your data at any time</li>
                  <li>Transaction records kept for 7 years (regulatory requirement)</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Regulatory Oversight</h4>
                <div className="grid sm:grid-cols-2 gap-2 text-sm">
                  <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded">
                    <p className="font-medium">SARB</p>
                    <p className="text-gray-600 dark:text-gray-400 text-xs">South African Reserve Bank</p>
                  </div>
                  <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded">
                    <p className="font-medium">FSCA</p>
                    <p className="text-gray-600 dark:text-gray-400 text-xs">Financial Sector Conduct Authority</p>
                  </div>
                  <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded">
                    <p className="font-medium">FIC</p>
                    <p className="text-gray-600 dark:text-gray-400 text-xs">Financial Intelligence Centre</p>
                  </div>
                  <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded">
                    <p className="font-medium">NCR</p>
                    <p className="text-gray-600 dark:text-gray-400 text-xs">National Credit Regulator</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fees Tab */}
        <TabsContent value="fees">
          <Card>
            <CardHeader>
              <CardTitle>Fee Schedule</CardTitle>
              <CardDescription>Transparent pricing for all services</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Account Fees</h4>
                  <div className="space-y-2">
                    {[
                      { label: 'Monthly Maintenance', fee: 'Free' },
                      { label: 'Account Opening', fee: 'Free' },
                      { label: 'Account Closure', fee: 'Free' },
                      { label: 'Digital Statements', fee: 'Free' },
                      { label: 'Paper Statements', fee: 'R25/month' },
                    ].map((item, i) => (
                      <div key={i} className="flex justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded text-sm">
                        <span>{item.label}</span>
                        <span className={item.fee === 'Free' ? 'text-green-600 font-medium' : 'font-medium'}>{item.fee}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Transaction Fees</h4>
                  <div className="space-y-2">
                    {[
                      { label: 'Internal Transfer', fee: 'Free' },
                      { label: 'External EFT', fee: 'R5' },
                      { label: 'Instant EFT', fee: 'R15' },
                      { label: 'Bill Payments', fee: 'Free' },
                      { label: 'International Transfer', fee: '1.5%' },
                    ].map((item, i) => (
                      <div key={i} className="flex justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded text-sm">
                        <span>{item.label}</span>
                        <span className={item.fee === 'Free' ? 'text-green-600 font-medium' : 'font-medium'}>{item.fee}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Card Fees</h4>
                  <div className="space-y-2">
                    {[
                      { label: 'Virtual Card', fee: 'Free' },
                      { label: 'Physical Debit Card', fee: 'R50' },
                      { label: 'Card Replacement', fee: 'R75' },
                      { label: 'ATM Withdrawals (4/month)', fee: 'Free' },
                      { label: 'Additional ATM Withdrawals', fee: 'R15' },
                    ].map((item, i) => (
                      <div key={i} className="flex justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded text-sm">
                        <span>{item.label}</span>
                        <span className={item.fee === 'Free' ? 'text-green-600 font-medium' : 'font-medium'}>{item.fee}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Other Fees</h4>
                  <div className="space-y-2">
                    {[
                      { label: 'Overdraft', fee: 'R150' },
                      { label: 'Returned Payment', fee: 'R100' },
                      { label: 'Stop Order', fee: 'R50' },
                      { label: 'Account Verification Letter', fee: 'R30' },
                      { label: 'Foreign Currency Conversion', fee: '2.5%' },
                    ].map((item, i) => (
                      <div key={i} className="flex justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded text-sm">
                        <span>{item.label}</span>
                        <span className="font-medium">{item.fee}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <Alert className="mt-6 border-blue-200 bg-blue-50 dark:bg-blue-950/20">
                <AlertCircle className="h-4 w-4 text-blue-600" />
                <AlertTitle className="text-blue-900 dark:text-blue-100">Premium Account Benefits</AlertTitle>
                <AlertDescription className="text-sm text-blue-800 dark:text-blue-200">
                  Premium accounts (R99/month) include: Higher transaction limits, unlimited free ATM withdrawals, free international transfers up to R50,000/month, and priority customer support.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Terms Tab */}
        <TabsContent value="terms">
          <Card>
            <CardHeader>
              <div className="flex items-start gap-4">
                <div className="p-3 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
                  <Shield className="w-6 h-6 text-indigo-600 dark:text-indigo-400" />
                </div>
                <div>
                  <CardTitle>Terms of Use</CardTitle>
                  <CardDescription>Last updated: October 9, 2025</CardDescription>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                    By using eWallet services, you agree to be bound by these terms.
                  </p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {[
                  {
                    title: '1. Account Terms',
                    content: 'You must provide accurate information and be at least 18 years old. You are responsible for maintaining account confidentiality. We reserve the right to refuse service or close accounts that violate our terms.',
                  },
                  {
                    title: '2. Privacy & Security',
                    content: 'We protect your privacy using industry-standard encryption. We never sell your personal information. You consent to our data collection as outlined in our Privacy Policy and are responsible for securing your login credentials.',
                  },
                  {
                    title: '3. Transactions',
                    content: 'Transactions may be delayed or cancelled if suspicious activity is detected. You authorize us to debit your account for all transactions you initiate. Disputed transactions must be reported within 60 days.',
                  },
                  {
                    title: '4. Fees & Charges',
                    content: 'Fees may change with 30 days notice. Overdraft fees of R150 apply for negative balances. International and currency conversion fees may apply. All fees are disclosed in our Fee Schedule.',
                  },
                  {
                    title: '5. Loans & Credit',
                    content: 'Loan approval is subject to credit verification. You agree to repay borrowed amounts according to the agreed schedule. Failure to pay may impact your credit score. We may report delinquent accounts to credit bureaus.',
                  },
                  {
                    title: '6. Investments',
                    content: 'Investment products are subject to market risk and you may lose money. Past performance does not guarantee future results. We do not provide investment advice. Investment accounts may have withdrawal restrictions.',
                  },
                  {
                    title: '7. Account Closure',
                    content: 'You may close your account anytime by withdrawing all funds. We reserve the right to close accounts for violation of terms, fraud, or inactivity. Accounts with zero balance for 12 months may be closed automatically.',
                  },
                  {
                    title: '8. Limitation of Liability',
                    content: 'eWallet is not liable for indirect or consequential damages. Our liability is limited to the amount in your account. We are not responsible for losses from unauthorized access due to your negligence.',
                  },
                  {
                    title: '9. Changes to Terms',
                    content: 'We may modify these terms at any time. You will be notified of significant changes via email. Continued use after changes constitutes acceptance. You may close your account if you disagree with updated terms.',
                  },
                ].map((term, index) => (
                  <div key={index} className="border-b pb-4 last:border-0">
                    <h3 className="font-medium mb-2">{term.title}</h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{term.content}</p>
                  </div>
                ))}

                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 mt-6">
                  <h4 className="font-medium mb-2">Contact Information</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                    For questions about these terms, contact us at:
                  </p>
                  <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                    <li>Email: legal@ewallet.co.za</li>
                    <li>Phone: 0861 392 5538</li>
                    <li>Address: 123 Financial District, Sandton, Johannesburg, 2196</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
