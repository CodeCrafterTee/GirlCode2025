import { useState } from 'react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import {
  Wallet,
  Home,
  ArrowLeftRight,
  TrendingUp,
  FileText,
  User,
  MessageSquare,
  LogOut,
  Menu,
  X,
  Moon,
  Sun,
  BookOpen,
  ShieldAlert,
} from 'lucide-react';
import { AccountsPage } from './AccountsPage';
import { TransactionsPage } from './TransactionsPage';
import { LoansInvestmentsPage } from './LoansInvestmentsPage';
import { TermsFAQsPage } from './TermsFAQsPage';
import { EditProfilePage } from './EditProfilePage';
import { QueriesPage } from './QueriesPage';
import { LearnPage } from './LearnPage';
import { AwarenessPage } from './AwarenessPage';
import { useTheme } from './ThemeProvider';

interface DashboardProps {
  onLogout: () => void;
}

export function Dashboard({ onLogout }: DashboardProps) {
  const [activePage, setActivePage] = useState('accounts');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const menuItems = [
    { id: 'accounts', label: 'Accounts', icon: Home },
    { id: 'transactions', label: 'Transactions', icon: ArrowLeftRight },
    { id: 'loans', label: 'Loans & Investments', icon: TrendingUp },
    { id: 'learn', label: 'Learn', icon: BookOpen },
    { id: 'awareness', label: 'Security Awareness', icon: ShieldAlert },
    { id: 'terms', label: 'Terms & FAQs', icon: FileText },
    { id: 'profile', label: 'Edit Profile', icon: User },
    { id: 'queries', label: 'Support', icon: MessageSquare },
  ];

  const renderPage = () => {
    switch (activePage) {
      case 'accounts':
        return <AccountsPage />;
      case 'transactions':
        return <TransactionsPage />;
      case 'loans':
        return <LoansInvestmentsPage />;
      case 'learn':
        return <LearnPage />;
      case 'awareness':
        return <AwarenessPage />;
      case 'terms':
        return <TermsFAQsPage />;
      case 'profile':
        return <EditProfilePage />;
      case 'queries':
        return <QueriesPage />;
      default:
        return <AccountsPage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950">
      {/* Header */}
      <header className="bg-white dark:bg-gray-900 border-b dark:border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg"
              >
                {isMobileMenuOpen ? (
                  <X className="w-6 h-6" />
                ) : (
                  <Menu className="w-6 h-6" />
                )}
              </button>
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-600 rounded-lg">
                  <Wallet className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl">eWallet ZA</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                className="rounded-full"
              >
                {theme === 'dark' ? (
                  <Sun className="w-5 h-5" />
                ) : (
                  <Moon className="w-5 h-5" />
                )}
              </Button>
              <Avatar>
                <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Latifah" />
                <AvatarFallback>LM</AvatarFallback>
              </Avatar>
              <div className="hidden sm:block">
                <p className="text-sm">Latifah Mmadi</p>
                <p className="text-xs text-muted-foreground">latifah.mmadi@example.com</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex gap-6">
          {/* Sidebar - Desktop */}
          <aside className="hidden md:block w-64 flex-shrink-0">
            <div className="bg-white dark:bg-gray-900 rounded-lg border dark:border-gray-800 p-4 sticky top-24">
              <nav className="space-y-1">
                {menuItems.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => setActivePage(item.id)}
                      className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                        activePage === item.id
                          ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400'
                          : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-sm">{item.label}</span>
                    </button>
                  );
                })}
                <button
                  onClick={onLogout}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 transition-colors mt-4"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="text-sm">Logout</span>
                </button>
              </nav>
            </div>
          </aside>

          {/* Mobile Menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-30 top-16">
              <div className="bg-white dark:bg-gray-900 w-64 h-full p-4">
                <nav className="space-y-1">
                  {menuItems.map((item) => {
                    const Icon = item.icon;
                    return (
                      <button
                        key={item.id}
                        onClick={() => {
                          setActivePage(item.id);
                          setIsMobileMenuOpen(false);
                        }}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                          activePage === item.id
                            ? 'bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400'
                            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-sm">{item.label}</span>
                      </button>
                    );
                  })}
                  <button
                    onClick={onLogout}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950 transition-colors mt-4"
                  >
                    <LogOut className="w-5 h-5" />
                    <span className="text-sm">Logout</span>
                  </button>
                </nav>
              </div>
            </div>
          )}

          {/* Main Content */}
          <main className="flex-1 min-w-0">{renderPage()}</main>
        </div>
      </div>
    </div>
  );
}
