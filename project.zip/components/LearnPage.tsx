import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { TrendingUp, BookOpen, Newspaper, Video, ExternalLink, DollarSign, PieChart, LineChart, Shield, AlertCircle } from 'lucide-react';
import { Badge } from './ui/badge';

export function LearnPage() {
  const investingBasics = [
    {
      title: 'What is Investing?',
      description: 'Learn the fundamentals of investing and how it can help you build wealth over time.',
      duration: '5 min read',
      level: 'Beginner',
      url: 'https://www.investopedia.com/terms/i/investing.asp',
    },
    {
      title: 'Understanding Risk vs Return',
      description: 'Discover how different investments balance potential rewards with their associated risks.',
      duration: '7 min read',
      level: 'Beginner',
      url: 'https://www.investopedia.com/articles/basics/03/050203.asp',
    },
    {
      title: 'The Power of Compound Interest',
      description: 'See how your investments can grow exponentially over time through compounding.',
      duration: '6 min read',
      level: 'Beginner',
      url: 'https://www.investopedia.com/terms/c/compoundinterest.asp',
    },
    {
      title: 'Diversification: Don\'t Put All Eggs in One Basket',
      description: 'Learn why spreading your investments across different assets is crucial for managing risk.',
      duration: '8 min read',
      level: 'Intermediate',
      url: 'https://www.investopedia.com/terms/d/diversification.asp',
    },
  ];

  const marketTrends = [
    {
      title: 'JSE Market Overview',
      description: 'Stay updated with the latest trends and movements in the Johannesburg Stock Exchange.',
      source: 'JSE',
      url: 'https://www.jse.co.za/',
    },
    {
      title: 'South African Economic Indicators',
      description: 'Track key economic indicators affecting investments in South Africa.',
      source: 'Statistics SA',
      url: 'https://www.statssa.gov.za/',
    },
    {
      title: 'Global Market News',
      description: 'Keep up with international market trends that impact local investments.',
      source: 'Bloomberg',
      url: 'https://www.bloomberg.com/markets',
    },
    {
      title: 'Cryptocurrency Market Trends',
      description: 'Explore the volatile world of digital currencies and blockchain technology.',
      source: 'CoinDesk',
      url: 'https://www.coindesk.com/',
    },
  ];

  const investmentTypes = [
    {
      icon: DollarSign,
      title: 'Stocks & Shares',
      description: 'Own a piece of a company and benefit from its growth and dividends.',
      riskLevel: 'High',
      potentialReturn: '8-12% annually',
    },
    {
      icon: PieChart,
      title: 'Mutual Funds',
      description: 'Professionally managed portfolios that pool money from many investors.',
      riskLevel: 'Medium',
      potentialReturn: '6-10% annually',
    },
    {
      icon: Shield,
      title: 'Bonds & Fixed Deposits',
      description: 'Lower-risk investments with guaranteed returns over a fixed period.',
      riskLevel: 'Low',
      potentialReturn: '4-6% annually',
    },
    {
      icon: LineChart,
      title: 'ETFs (Exchange Traded Funds)',
      description: 'Track market indices and trade like stocks with lower fees.',
      riskLevel: 'Medium',
      potentialReturn: '7-11% annually',
    },
  ];

  const videoResources = [
    {
      title: 'Investing 101: Getting Started',
      platform: 'Khan Academy',
      description: 'Complete beginner\'s guide to understanding the stock market and investments.',
      url: 'https://www.khanacademy.org/economics-finance-domain/core-finance',
    },
    {
      title: 'Personal Finance in South Africa',
      platform: 'YouTube',
      description: 'Learn about saving, investing, and building wealth in the South African context.',
      url: 'https://www.youtube.com/results?search_query=south+africa+investing+basics',
    },
    {
      title: 'Understanding the JSE',
      platform: 'JSE Learning',
      description: 'Educational resources directly from the Johannesburg Stock Exchange.',
      url: 'https://www.jse.co.za/learn',
    },
  ];

  const financialTools = [
    {
      title: 'Compound Interest Calculator',
      description: 'See how your investments can grow over time with compound interest.',
      url: 'https://www.calculator.net/investment-calculator.html',
    },
    {
      title: 'Retirement Planning Calculator',
      description: 'Plan for your future and determine how much you need to save.',
      url: 'https://www.investopedia.com/retirement-calculator-5085162',
    },
    {
      title: 'Risk Tolerance Assessment',
      description: 'Understand your investment personality and risk appetite.',
      url: 'https://www.investopedia.com/articles/00/082800.asp',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Learn & Grow</h1>
        <p className="text-gray-600 dark:text-gray-400">Expand your financial knowledge and make informed investment decisions</p>
      </div>

      <Tabs defaultValue="basics" className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
          <TabsTrigger value="basics">Basics</TabsTrigger>
          <TabsTrigger value="market">Market Trends</TabsTrigger>
          <TabsTrigger value="types">Investment Types</TabsTrigger>
          <TabsTrigger value="resources">Resources</TabsTrigger>
        </TabsList>

        <TabsContent value="basics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Investing Basics
              </CardTitle>
              <CardDescription>Essential knowledge to start your investment journey</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {investingBasics.map((article, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <h3 className="font-medium pr-2">{article.title}</h3>
                      <Badge variant="outline" className="shrink-0">{article.level}</Badge>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{article.description}</p>
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-xs text-gray-500">{article.duration}</span>
                      <Button variant="outline" size="sm" asChild>
                        <a href={article.url} target="_blank" rel="noopener noreferrer">
                          Read More
                          <ExternalLink className="w-3 h-3 ml-1" />
                        </a>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-blue-900 dark:text-blue-100">
                <AlertCircle className="w-5 h-5" />
                Getting Started Tip
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <p>Before you start investing, make sure you have:</p>
              <ul className="space-y-2 list-disc list-inside">
                <li>An emergency fund covering 3-6 months of expenses</li>
                <li>High-interest debt paid off (credit cards, personal loans)</li>
                <li>Clear financial goals and timeline</li>
                <li>Basic understanding of investment options</li>
                <li>A budget that allows for regular contributions</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="market" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Newspaper className="w-5 h-5" />
                Market News & Trends
              </CardTitle>
              <CardDescription>Stay informed about market movements and economic trends</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {marketTrends.map((trend, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <h3 className="font-medium">{trend.title}</h3>
                      <TrendingUp className="w-5 h-5 text-green-600" />
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{trend.description}</p>
                    <div className="flex items-center justify-between pt-2">
                      <span className="text-xs text-gray-500">Source: {trend.source}</span>
                      <Button variant="outline" size="sm" asChild>
                        <a href={trend.url} target="_blank" rel="noopener noreferrer">
                          Visit
                          <ExternalLink className="w-3 h-3 ml-1" />
                        </a>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Financial Calculators & Tools</CardTitle>
              <CardDescription>Plan your investments with these helpful tools</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {financialTools.map((tool, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
                    <div>
                      <h4 className="font-medium text-sm">{tool.title}</h4>
                      <p className="text-xs text-gray-600 dark:text-gray-400">{tool.description}</p>
                    </div>
                    <Button variant="ghost" size="sm" asChild>
                      <a href={tool.url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="types" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Types of Investments</CardTitle>
              <CardDescription>Compare different investment options and their characteristics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {investmentTypes.map((type, index) => {
                  const Icon = type.icon;
                  const getRiskColor = (risk: string) => {
                    switch (risk) {
                      case 'Low':
                        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
                      case 'Medium':
                        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
                      case 'High':
                        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
                      default:
                        return '';
                    }
                  };

                  return (
                    <div key={index} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-indigo-100 dark:bg-indigo-900 rounded-lg">
                          <Icon className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{type.title}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{type.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t">
                        <div>
                          <p className="text-xs text-gray-500">Risk Level</p>
                          <Badge className={getRiskColor(type.riskLevel)} variant="outline">
                            {type.riskLevel}
                          </Badge>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-gray-500">Potential Return</p>
                          <p className="text-sm font-medium">{type.potentialReturn}</p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-orange-900 dark:text-orange-100">
                <AlertCircle className="w-5 h-5" />
                Important Reminder
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm">
                Past performance is not indicative of future results. All investments carry risk, 
                including the potential loss of principal. The returns shown are historical averages 
                and should not be considered guaranteed. Always do your own research and consider 
                consulting with a financial advisor before making investment decisions.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="resources" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Video className="w-5 h-5" />
                Video Learning Resources
              </CardTitle>
              <CardDescription>Watch and learn at your own pace</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {videoResources.map((video, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-2 hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium">{video.title}</h3>
                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{video.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2">
                      <Badge variant="secondary">{video.platform}</Badge>
                      <Button variant="outline" size="sm" asChild>
                        <a href={video.url} target="_blank" rel="noopener noreferrer">
                          Watch Now
                          <ExternalLink className="w-3 h-3 ml-1" />
                        </a>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recommended Books</CardTitle>
              <CardDescription>Classic reads for investors</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <h4 className="font-medium text-sm">The Intelligent Investor by Benjamin Graham</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">The definitive book on value investing</p>
                </div>
                <div className="p-3 border rounded-lg">
                  <h4 className="font-medium text-sm">Rich Dad Poor Dad by Robert Kiyosaki</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Learn about financial literacy and building wealth</p>
                </div>
                <div className="p-3 border rounded-lg">
                  <h4 className="font-medium text-sm">A Random Walk Down Wall Street by Burton Malkiel</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Understand different investment strategies</p>
                </div>
                <div className="p-3 border rounded-lg">
                  <h4 className="font-medium text-sm">The Little Book of Common Sense Investing by John C. Bogle</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">Simple strategies for index fund investing</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>South African Resources</CardTitle>
              <CardDescription>Local financial education and news</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button variant="outline" className="w-full justify-between" asChild>
                  <a href="https://www.moneyweb.co.za/" target="_blank" rel="noopener noreferrer">
                    Moneyweb - SA Financial News
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <a href="https://www.fin24.com/" target="_blank" rel="noopener noreferrer">
                    Fin24 - Finance News
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </Button>
                <Button variant="outline" className="w-full justify-between" asChild>
                  <a href="https://www.oldmutual.co.za/personal/education-centre/" target="_blank" rel="noopener noreferrer">
                    Old Mutual Education Centre
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
