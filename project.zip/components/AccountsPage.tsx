import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Wallet, TrendingUp, Send, ArrowDownToLine, Eye, EyeOff, Plus, Info } from 'lucide-react';
import { useState } from 'react';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';

export function AccountsPage() {
  const [showBalance, setShowBalance] = useState(true);
  const [hasSavingsAccount, setHasSavingsAccount] = useState(false);

  const mainAccount = {
    balance: 0,
    accountNumber: '**** **** ' + Math.floor(1000 + Math.random() * 9000),
    type: 'Main Account',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl">My Accounts</h1>
          <p className="text-gray-600 dark:text-gray-400">Manage your accounts and balances</p>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setShowBalance(!showBalance)}
        >
          {showBalance ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
          {showBalance ? 'Hide' : 'Show'} Balance
        </Button>
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Welcome to eWallet!</AlertTitle>
        <AlertDescription>
          Your account is ready to use. Add funds to get started with payments, transfers, and more. Visit the Learn page to discover investment opportunities.
        </AlertDescription>
      </Alert>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-br from-indigo-600 to-indigo-800 dark:from-indigo-700 dark:to-indigo-950 text-white border-0">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Main Account</CardTitle>
              <Wallet className="w-6 h-6" />
            </div>
            <CardDescription className="text-indigo-100">
              {mainAccount.accountNumber}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-indigo-100">Available Balance</p>
                <p className="text-3xl">
                  {showBalance ? `R${mainAccount.balance.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}` : '****'}
                </p>
              </div>
              <div className="flex gap-2">
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="secondary" className="flex-1">
                      <Send className="w-4 h-4 mr-2" />
                      Send
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Send Money</DialogTitle>
                      <DialogDescription>
                        You need to add funds to your account before you can send money.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Alert>
                        <Info className="h-4 w-4" />
                        <AlertTitle>Add Funds First</AlertTitle>
                        <AlertDescription>
                          Deposit money via bank transfer, card, or cash at participating stores. See the Terms & Policies page for deposit methods.
                        </AlertDescription>
                      </Alert>
                    </div>
                  </DialogContent>
                </Dialog>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" variant="secondary" className="flex-1">
                      <ArrowDownToLine className="w-4 h-4 mr-2" />
                      Receive
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Receive Money</DialogTitle>
                      <DialogDescription>
                        Share your account details to receive payments
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Account Number</p>
                        <p className="font-mono text-lg">{mainAccount.accountNumber}</p>
                      </div>
                      <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Bank Name</p>
                        <p className="text-lg">eWallet Digital Bank</p>
                      </div>
                      <div className="p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Branch Code</p>
                        <p className="font-mono text-lg">250655</p>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {!hasSavingsAccount ? (
          <Card className="border-2 border-dashed border-gray-300 dark:border-gray-700">
            <CardContent className="flex flex-col items-center justify-center h-full py-12">
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mb-4">
                <TrendingUp className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-lg mb-2">Open a Savings Account</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 text-center mb-4 max-w-xs">
                Start saving with 3.5% APY interest. No minimum balance required.
              </p>
              <Button onClick={() => setHasSavingsAccount(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Open Savings Account
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card className="bg-gradient-to-br from-green-600 to-green-800 dark:from-green-700 dark:to-green-950 text-white border-0">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">Savings Account</CardTitle>
                <TrendingUp className="w-6 h-6" />
              </div>
              <CardDescription className="text-green-100">
                **** **** {Math.floor(1000 + Math.random() * 9000)}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-green-100">Current Savings</p>
                  <p className="text-3xl">
                    {showBalance ? 'R0.00' : '****'}
                  </p>
                </div>
                <div className="bg-green-900 bg-opacity-50 rounded-lg p-3">
                  <p className="text-sm">Interest Rate</p>
                  <p className="text-xl">3.5% APY</p>
                </div>
                <Button size="sm" variant="secondary" className="w-full">
                  <Send className="w-4 h-4 mr-2" />
                  Transfer to Savings
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest transactions across all accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-12">
            <div className="mx-auto w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4">
              <ArrowDownToLine className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-lg mb-2">No Transactions Yet</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm max-w-md mx-auto">
              Your transaction history will appear here once you start using your account.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Monthly Income</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl text-gray-400">R0.00</p>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Monthly Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl text-gray-400">R0.00</p>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Net Savings</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl text-gray-400">R0.00</p>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
