import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Send, Bot, User, Phone, Mail, MessageSquare } from 'lucide-react';
import { ScrollArea } from './ui/scroll-area';

export function QueriesPage() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'bot',
      text: 'Hello! I\'m your eWallet assistant. How can I help you today?',
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const quickQuestions = [
    'How do I transfer money?',
    'What are my transaction limits?',
    'How do I apply for a loan?',
    'Reset my password',
    'Update my profile',
  ];

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const userMessage = {
      id: messages.length + 1,
      sender: 'user',
      text: inputMessage,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages([...messages, userMessage]);
    setInputMessage('');

    setTimeout(() => {
      const botResponse = {
        id: messages.length + 2,
        sender: 'bot',
        text: getBotResponse(inputMessage),
        time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botResponse]);
    }, 1000);
  };

  const handleQuickQuestion = (question: string) => {
    setInputMessage(question);
  };

  const getBotResponse = (message: string): string => {
    const lowerMessage = message.toLowerCase();

    if (lowerMessage.includes('transfer') || lowerMessage.includes('send money')) {
      return 'To transfer money, go to the Accounts page and click the "Send" button. Enter the recipient\'s details and the amount. Transfers to other eWallet users are instant and free!';
    } else if (lowerMessage.includes('limit')) {
      return 'Your daily transaction limit is R20,000 for standard accounts and R100,000 for premium accounts. Monthly limits are R200,000 and R500,000 respectively. You can request a limit increase through your profile settings.';
    } else if (lowerMessage.includes('loan')) {
      return 'To apply for a loan, navigate to the Loans & Investments page. We offer Personal Loans, Home Loans, and Business Loans with competitive interest rates. The application process takes about 10 minutes, and you\'ll receive a decision within 24-48 hours.';
    } else if (lowerMessage.includes('password')) {
      return 'To reset your password, go to Edit Profile > Security tab. You can also use the "Forgot Password" link on the login page. For security, you\'ll need to verify your identity via email or SMS.';
    } else if (lowerMessage.includes('profile') || lowerMessage.includes('update')) {
      return 'You can update your profile information by going to the Edit Profile page. From there, you can change your personal details, security settings, notification preferences, and more.';
    } else if (lowerMessage.includes('fee') || lowerMessage.includes('charge')) {
      return 'eWallet has transparent fees: No monthly maintenance fees, free internal transfers, up to 4 free ATM withdrawals per month, R50 for external EFT transfers, and 1% for international transfers (minimum R20).';
    } else if (lowerMessage.includes('support') || lowerMessage.includes('help')) {
      return 'Our customer support team is available 24/7. You can chat with me here, email us at support@ewallet.co.za, or call 0800-EWALLET. We\'re here to help!';
    } else {
      return 'I understand your query. For detailed assistance, I can connect you with a live agent, or you can browse our FAQs in the Terms & FAQs page. Is there anything specific I can help you with?';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Customer Support</h1>
        <p className="text-gray-600">Get help and support for your account</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <Card className="cursor-pointer hover:shadow-lg transition-shadow">
          <CardContent className="pt-6 text-center">
            <div className="p-3 bg-indigo-100 rounded-full w-fit mx-auto mb-3">
              <Phone className="w-6 h-6 text-indigo-600" />
            </div>
            <h3 className="font-medium mb-1">Call Us</h3>
            <p className="text-sm text-gray-600">1-800-EWALLET</p>
            <p className="text-xs text-gray-500 mt-1">24/7 Support</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow">
          <CardContent className="pt-6 text-center">
            <div className="p-3 bg-green-100 rounded-full w-fit mx-auto mb-3">
              <Mail className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="font-medium mb-1">Email Us</h3>
            <p className="text-sm text-gray-600">support@ewallet.com</p>
            <p className="text-xs text-gray-500 mt-1">Response within 24hrs</p>
          </CardContent>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow">
          <CardContent className="pt-6 text-center">
            <div className="p-3 bg-purple-100 rounded-full w-fit mx-auto mb-3">
              <MessageSquare className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="font-medium mb-1">Live Chat</h3>
            <p className="text-sm text-gray-600">Chat with an agent</p>
            <p className="text-xs text-gray-500 mt-1">Available now</p>
          </CardContent>
        </Card>
      </div>

      <Card className="h-[600px] flex flex-col">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>AI Assistant</CardTitle>
              <CardDescription>Ask me anything about your account</CardDescription>
            </div>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
              Online
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col p-0">
          <div className="px-6 pb-4">
            <p className="text-sm text-gray-600 mb-2">Quick questions:</p>
            <div className="flex flex-wrap gap-2">
              {quickQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handleQuickQuestion(question)}
                >
                  {question}
                </Button>
              ))}
            </div>
          </div>

          <div className="flex-1 px-6 pb-4 overflow-y-auto" ref={scrollRef}>
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex items-start gap-3 ${
                    message.sender === 'user' ? 'flex-row-reverse' : ''
                  }`}
                >
                  <div
                    className={`p-2 rounded-full ${
                      message.sender === 'bot'
                        ? 'bg-indigo-100'
                        : 'bg-gray-200'
                    }`}
                  >
                    {message.sender === 'bot' ? (
                      <Bot className="w-5 h-5 text-indigo-600" />
                    ) : (
                      <User className="w-5 h-5 text-gray-600" />
                    )}
                  </div>
                  <div
                    className={`flex-1 max-w-[80%] ${
                      message.sender === 'user' ? 'text-right' : ''
                    }`}
                  >
                    <div
                      className={`inline-block rounded-lg px-4 py-2 ${
                        message.sender === 'bot'
                          ? 'bg-gray-100 text-gray-900'
                          : 'bg-indigo-600 text-white'
                      }`}
                    >
                      <p className="text-sm">{message.text}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{message.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t p-4">
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <Input
                placeholder="Type your message..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
