import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { TrendingUp, DollarSign, Calendar, Percent, AlertTriangle, CheckCircle2, FileText, User, Briefcase, Home, Info } from 'lucide-react';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Checkbox } from './ui/checkbox';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { toast } from 'sonner@2.0.3';

export function LoansInvestmentsPage() {
  const [loanDialogOpen, setLoanDialogOpen] = useState(false);
  const [selectedLoanType, setSelectedLoanType] = useState('');
  const [investmentAccepted, setInvestmentAccepted] = useState(false);
  const [showInvestmentDisclaimer, setShowInvestmentDisclaimer] = useState(true);

  // Loan application form state
  const [loanForm, setLoanForm] = useState({
    loanType: '',
    amount: '',
    purpose: '',
    tenure: '',
    monthlyIncome: '',
    employmentStatus: '',
    employer: '',
    yearsEmployed: '',
    existingLoans: '',
    idNumber: '',
    address: '',
  });

  const activeLoans: any[] = [];
  const investments: any[] = [];

  const loanOptions = [
    {
      name: 'Personal Loan',
      maxAmount: 25000,
      interestRate: 7.9,
      tenure: '1-5 years',
      description: 'For personal needs and expenses',
    },
    {
      name: 'Home Loan',
      maxAmount: 500000,
      interestRate: 5.5,
      tenure: '5-30 years',
      description: 'Finance your dream home',
    },
    {
      name: 'Business Loan',
      maxAmount: 100000,
      interestRate: 9.5,
      tenure: '1-10 years',
      description: 'Grow your business',
    },
  ];

  const investmentOptions = [
    {
      name: 'Fixed Deposit',
      minAmount: 1000,
      returnRate: 4.5,
      risk: 'Low',
      description: 'Guaranteed returns with capital protection',
    },
    {
      name: 'Mutual Funds',
      minAmount: 500,
      returnRate: 10.0,
      risk: 'Medium',
      description: 'Professionally managed investment portfolio',
    },
    {
      name: 'Stocks',
      minAmount: 100,
      returnRate: 12.0,
      risk: 'High',
      description: 'Direct equity investment in companies',
    },
  ];

  const totalLoaned = activeLoans.reduce((sum, loan) => sum + loan.amount, 0);
  const totalRemaining = activeLoans.reduce((sum, loan) => sum + loan.remaining, 0);
  const totalInvested = investments.reduce((sum, inv) => sum + inv.invested, 0);
  const totalReturns = investments.reduce((sum, inv) => sum + inv.returns, 0);

  const handleLoanApplication = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock loan application submission
    toast.success('Loan Application Submitted!', {
      description: 'We will review your application and get back to you within 48 hours.',
    });
    setLoanDialogOpen(false);
    // Reset form
    setLoanForm({
      loanType: '',
      amount: '',
      purpose: '',
      tenure: '',
      monthlyIncome: '',
      employmentStatus: '',
      employer: '',
      yearsEmployed: '',
      existingLoans: '',
      idNumber: '',
      address: '',
    });
  };

  const handleAcceptInvestmentTerms = () => {
    setInvestmentAccepted(true);
    setShowInvestmentDisclaimer(false);
    toast.success('Investment Terms Accepted', {
      description: 'You can now access our investment products.',
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Loans & Investments</h1>
        <p className="text-gray-600 dark:text-gray-400">Manage your loans and grow your wealth</p>
      </div>

      <Tabs defaultValue="loans" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="loans">Loans</TabsTrigger>
          <TabsTrigger value="investments">Investments</TabsTrigger>
        </TabsList>

        <TabsContent value="loans" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Total Borrowed</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl">R{totalLoaned.toLocaleString('en-ZA')}</p>
                <p className="text-xs text-gray-500 mt-1">{activeLoans.length} active loans</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Total Outstanding</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-2xl text-orange-600">R{totalRemaining.toLocaleString('en-ZA')}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {totalLoaned > 0 ? `${((totalRemaining / totalLoaned) * 100).toFixed(0)}% remaining` : 'No outstanding loans'}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Active Loans</CardTitle>
              <CardDescription>Your current loan obligations</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {activeLoans.length === 0 ? (
                <div className="text-center py-12">
                  <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-3">
                    <DollarSign className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-600 dark:text-gray-400">No active loans</p>
                  <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                    Apply for a loan below to get started
                  </p>
                </div>
              ) : (
                activeLoans.map((loan) => {
                  const progress = ((loan.amount - loan.remaining) / loan.amount) * 100;
                  return (
                    <div key={loan.id} className="border rounded-lg p-4 space-y-3">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium">{loan.type}</h4>
                          <p className="text-sm text-gray-500">Loan Amount: R{loan.amount.toLocaleString('en-ZA')}</p>
                        </div>
                        <Badge>{loan.status}</Badge>
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Repayment Progress</span>
                          <span>{progress.toFixed(0)}%</span>
                        </div>
                        <Progress value={progress} />
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Remaining</p>
                          <p className="font-medium">R{loan.remaining.toLocaleString('en-ZA')}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Monthly Payment</p>
                          <p className="font-medium">R{loan.monthlyPayment}</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Interest Rate</p>
                          <p className="font-medium">{loan.interestRate}%</p>
                        </div>
                        <div>
                          <p className="text-gray-500">Next Payment</p>
                          <p className="font-medium">{loan.nextPayment}</p>
                        </div>
                      </div>
                      <Button variant="outline" size="sm" className="w-full">
                        Make Payment
                      </Button>
                    </div>
                  );
                })
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Apply for a Loan</CardTitle>
              <CardDescription>Choose from our loan products and complete the application</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {loanOptions.map((option, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3">
                    <h4 className="font-medium">{option.name}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{option.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-gray-500" />
                        <span>Up to R{option.maxAmount.toLocaleString('en-ZA')}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Percent className="w-4 h-4 text-gray-500" />
                        <span>{option.interestRate}% interest</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-gray-500" />
                        <span>{option.tenure}</span>
                      </div>
                    </div>
                    <Dialog open={loanDialogOpen && selectedLoanType === option.name} onOpenChange={(open) => {
                      setLoanDialogOpen(open);
                      if (!open) setSelectedLoanType('');
                    }}>
                      <DialogTrigger asChild>
                        <Button 
                          className="w-full" 
                          size="sm"
                          onClick={() => {
                            setSelectedLoanType(option.name);
                            setLoanForm({ ...loanForm, loanType: option.name });
                          }}
                        >
                          Apply Now
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle>Loan Application - {option.name}</DialogTitle>
                          <DialogDescription>
                            Please complete all fields below. Your information will be kept confidential.
                          </DialogDescription>
                        </DialogHeader>
                        <form onSubmit={handleLoanApplication} className="space-y-6">
                          {/* Loan Details */}
                          <div className="space-y-4">
                            <h3 className="flex items-center gap-2">
                              <FileText className="w-5 h-5" />
                              Loan Details
                            </h3>
                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="amount">Loan Amount (R)</Label>
                                <Input
                                  id="amount"
                                  type="number"
                                  placeholder="e.g., 10000"
                                  value={loanForm.amount}
                                  onChange={(e) => setLoanForm({ ...loanForm, amount: e.target.value })}
                                  required
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="tenure">Loan Tenure</Label>
                                <Select 
                                  value={loanForm.tenure}
                                  onValueChange={(value) => setLoanForm({ ...loanForm, tenure: value })}
                                  required
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select tenure" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="12">12 months</SelectItem>
                                    <SelectItem value="24">24 months</SelectItem>
                                    <SelectItem value="36">36 months</SelectItem>
                                    <SelectItem value="48">48 months</SelectItem>
                                    <SelectItem value="60">60 months</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="purpose">Loan Purpose</Label>
                              <Textarea
                                id="purpose"
                                placeholder="Briefly describe why you need this loan"
                                value={loanForm.purpose}
                                onChange={(e) => setLoanForm({ ...loanForm, purpose: e.target.value })}
                                required
                              />
                            </div>
                          </div>

                          {/* Personal Information */}
                          <div className="space-y-4">
                            <h3 className="flex items-center gap-2">
                              <User className="w-5 h-5" />
                              Personal Information
                            </h3>
                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="idNumber">SA ID Number</Label>
                                <Input
                                  id="idNumber"
                                  placeholder="e.g., 9001015800088"
                                  value={loanForm.idNumber}
                                  onChange={(e) => setLoanForm({ ...loanForm, idNumber: e.target.value })}
                                  required
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="monthlyIncome">Monthly Income (R)</Label>
                                <Input
                                  id="monthlyIncome"
                                  type="number"
                                  placeholder="e.g., 15000"
                                  value={loanForm.monthlyIncome}
                                  onChange={(e) => setLoanForm({ ...loanForm, monthlyIncome: e.target.value })}
                                  required
                                />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="address">Residential Address</Label>
                              <Textarea
                                id="address"
                                placeholder="Your full residential address"
                                value={loanForm.address}
                                onChange={(e) => setLoanForm({ ...loanForm, address: e.target.value })}
                                required
                              />
                            </div>
                          </div>

                          {/* Employment Information */}
                          <div className="space-y-4">
                            <h3 className="flex items-center gap-2">
                              <Briefcase className="w-5 h-5" />
                              Employment Information
                            </h3>
                            <div className="grid md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="employmentStatus">Employment Status</Label>
                                <Select 
                                  value={loanForm.employmentStatus}
                                  onValueChange={(value) => setLoanForm({ ...loanForm, employmentStatus: value })}
                                  required
                                >
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select status" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="permanent">Permanent Employee</SelectItem>
                                    <SelectItem value="contract">Contract Employee</SelectItem>
                                    <SelectItem value="self-employed">Self-Employed</SelectItem>
                                    <SelectItem value="retired">Retired</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="yearsEmployed">Years in Current Employment</Label>
                                <Input
                                  id="yearsEmployed"
                                  type="number"
                                  placeholder="e.g., 3"
                                  value={loanForm.yearsEmployed}
                                  onChange={(e) => setLoanForm({ ...loanForm, yearsEmployed: e.target.value })}
                                  required
                                />
                              </div>
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="employer">Employer Name</Label>
                              <Input
                                id="employer"
                                placeholder="Your employer's name"
                                value={loanForm.employer}
                                onChange={(e) => setLoanForm({ ...loanForm, employer: e.target.value })}
                                required
                              />
                            </div>
                          </div>

                          {/* Existing Obligations */}
                          <div className="space-y-4">
                            <h3 className="flex items-center gap-2">
                              <Home className="w-5 h-5" />
                              Financial Obligations
                            </h3>
                            <div className="space-y-2">
                              <Label htmlFor="existingLoans">Existing Loans/Debts (R per month)</Label>
                              <Input
                                id="existingLoans"
                                type="number"
                                placeholder="Total monthly debt payments (enter 0 if none)"
                                value={loanForm.existingLoans}
                                onChange={(e) => setLoanForm({ ...loanForm, existingLoans: e.target.value })}
                                required
                              />
                            </div>
                          </div>

                          <Alert>
                            <Info className="h-4 w-4" />
                            <AlertTitle>Application Notice</AlertTitle>
                            <AlertDescription>
                              By submitting this application, you consent to a credit check and agree to our lending terms and conditions. 
                              The approval process typically takes 24-48 hours.
                            </AlertDescription>
                          </Alert>

                          <div className="flex gap-3">
                            <Button type="submit" className="flex-1">
                              Submit Application
                            </Button>
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => setLoanDialogOpen(false)}
                              className="flex-1"
                            >
                              Cancel
                            </Button>
                          </div>
                        </form>
                      </DialogContent>
                    </Dialog>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="investments" className="space-y-6">
          {showInvestmentDisclaimer && !investmentAccepted ? (
            <Card className="border-orange-200 bg-orange-50 dark:bg-orange-950/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="w-6 h-6 text-orange-600" />
                  Investment Disclaimer & Education
                </CardTitle>
                <CardDescription>
                  Please read the following information carefully before proceeding
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Important Risk Warning</AlertTitle>
                    <AlertDescription>
                      Investments carry risk and you may lose some or all of your capital. 
                      Past performance does not guarantee future results. Only invest money you can afford to lose.
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-3">
                    <h4 className="flex items-center gap-2">
                      <TrendingUp className="w-5 h-5 text-green-600" />
                      Tips for Successful Investing
                    </h4>
                    <ul className="space-y-2 text-sm">
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Diversify your portfolio:</strong> Don't put all your eggs in one basket. Spread investments across different asset types.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Invest for the long term:</strong> Markets fluctuate. Long-term investments generally perform better than short-term trading.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Understand your risk tolerance:</strong> Choose investments that match your comfort level with potential losses.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Start small:</strong> Begin with smaller amounts until you're comfortable with how investments work.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Research before investing:</strong> Understand what you're investing in and how it generates returns.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Review regularly:</strong> Monitor your investments and rebalance your portfolio periodically.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
                        <span><strong>Consider professional advice:</strong> Consult a qualified financial advisor for personalized guidance.</span>
                      </li>
                    </ul>
                  </div>

                  <div className="space-y-3 p-4 bg-blue-50 dark:bg-blue-950/20 rounded-lg border border-blue-200">
                    <h4 className="flex items-center gap-2">
                      <Info className="w-5 h-5 text-blue-600" />
                      Understanding Risk Levels
                    </h4>
                    <div className="space-y-2 text-sm">
                      <p><strong>Low Risk:</strong> Minimal chance of losing capital, but lower potential returns (e.g., Fixed Deposits, Government Bonds)</p>
                      <p><strong>Medium Risk:</strong> Balanced approach with moderate potential for both gains and losses (e.g., Mutual Funds, Balanced Portfolios)</p>
                      <p><strong>High Risk:</strong> Greater potential returns but also higher chance of losses (e.g., Individual Stocks, Cryptocurrencies)</p>
                    </div>
                  </div>

                  <div className="space-y-3 p-4 bg-gray-100 dark:bg-gray-800 rounded-lg">
                    <h4>Key Investment Principles</h4>
                    <ul className="space-y-1 text-sm list-disc list-inside">
                      <li>Your capital is at risk and may go down as well as up</li>
                      <li>Returns are not guaranteed and depend on market conditions</li>
                      <li>You should have emergency savings before investing</li>
                      <li>Never invest borrowed money or funds needed for essentials</li>
                      <li>Tax implications may apply to investment gains</li>
                      <li>Early withdrawal may result in penalties or losses</li>
                    </ul>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-4 border-2 border-gray-300 dark:border-gray-600 rounded-lg">
                  <Checkbox 
                    id="accept-investment-terms"
                    onCheckedChange={(checked) => {
                      if (checked) {
                        handleAcceptInvestmentTerms();
                      }
                    }}
                  />
                  <div className="space-y-1">
                    <label
                      htmlFor="accept-investment-terms"
                      className="text-sm cursor-pointer leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      <strong>I acknowledge and accept the risks</strong>
                    </label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      I understand that investments carry risk, I may lose money, and past performance does not guarantee future results. 
                      I confirm that I have read and understood the investment tips and risk levels explained above.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Total Invested</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl">R{totalInvested.toLocaleString('en-ZA')}</p>
                    <p className="text-xs text-gray-500 mt-1">{investments.length} active investments</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm">Total Returns</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl text-green-600">+R{totalReturns.toLocaleString('en-ZA')}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      {totalInvested > 0 ? `${((totalReturns / totalInvested) * 100).toFixed(2)}% return` : 'No returns yet'}
                    </p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>My Investments</CardTitle>
                  <CardDescription>Track your investment portfolio</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {investments.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-3">
                        <TrendingUp className="w-8 h-8 text-gray-400" />
                      </div>
                      <p className="text-gray-600 dark:text-gray-400">No investments yet</p>
                      <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                        Choose an investment option below to start building wealth
                      </p>
                    </div>
                  ) : (
                    investments.map((investment) => {
                      const getRiskColor = (type: string) => {
                        switch (type) {
                          case 'low-risk':
                            return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
                          case 'medium-risk':
                            return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
                          case 'high-risk':
                            return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
                          default:
                            return 'bg-gray-100 text-gray-800';
                        }
                      };

                      return (
                        <div key={investment.id} className="border rounded-lg p-4 space-y-3">
                          <div className="flex items-start justify-between">
                            <div>
                              <h4 className="font-medium">{investment.name}</h4>
                              <p className="text-sm text-gray-500">Invested: R{investment.invested.toLocaleString('en-ZA')}</p>
                            </div>
                            <Badge className={getRiskColor(investment.type)}>
                              {investment.type.replace('-', ' ')}
                            </Badge>
                          </div>
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <p className="text-gray-500">Current Value</p>
                              <p className="font-medium">R{investment.currentValue.toLocaleString('en-ZA')}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Returns</p>
                              <p className="font-medium text-green-600">+R{investment.returns.toLocaleString('en-ZA')}</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Return Rate</p>
                              <p className="font-medium">{investment.returnRate}%</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Maturity</p>
                              <p className="font-medium">{investment.maturityDate}</p>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" className="flex-1">
                              View Details
                            </Button>
                            <Button variant="outline" size="sm" className="flex-1">
                              Add Funds
                            </Button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Investment Options</CardTitle>
                  <CardDescription>Start investing today</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    {investmentOptions.map((option, index) => (
                      <div key={index} className="border rounded-lg p-4 space-y-3">
                        <div className="flex items-start justify-between">
                          <h4 className="font-medium">{option.name}</h4>
                          <TrendingUp className="w-5 h-5 text-green-600" />
                        </div>
                        <p className="text-sm text-gray-600 dark:text-gray-400">{option.description}</p>
                        <div className="space-y-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-gray-500">Min. Investment</span>
                            <span className="font-medium">R{option.minAmount}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Expected Return</span>
                            <span className="font-medium text-green-600">{option.returnRate}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-500">Risk Level</span>
                            <Badge variant="outline">{option.risk}</Badge>
                          </div>
                        </div>
                        <Button className="w-full" size="sm">
                          Invest Now
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowInvestmentDisclaimer(true)}
                className="w-full"
              >
                <Info className="w-4 h-4 mr-2" />
                View Investment Guidelines Again
              </Button>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
