import { Alert, AlertDescription, AlertTitle } from './ui/alert';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import {
  Shield,
  Lock,
  AlertTriangle,
  Eye,
  Phone,
  Mail,
  UserX,
  Key,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Info,
} from 'lucide-react';
import { Badge } from './ui/badge';

export function AwarenessPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-amber-100 dark:bg-amber-950 rounded-lg">
            <ShieldAlert className="w-6 h-6 text-amber-600 dark:text-amber-400" />
          </div>
          <h1 className="text-3xl">Security Awareness</h1>
        </div>
        <p className="text-muted-foreground">
          Protect your account and financial information. Learn how to keep your eWallet ZA account secure.
        </p>
      </div>

      {/* Critical Alert */}
      <Alert className="border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950">
        <AlertTriangle className="h-5 w-5 text-red-600 dark:text-red-400" />
        <AlertTitle className="text-red-800 dark:text-red-200">Important Security Notice</AlertTitle>
        <AlertDescription className="text-red-700 dark:text-red-300">
          <strong>Never share your password, PIN, or OTP codes with anyone</strong> - not even eWallet ZA staff.
          We will never ask you for this information via email, SMS, or phone call.
        </AlertDescription>
      </Alert>

      {/* What We'll Never Ask For */}
      <Card className="border-amber-200 dark:border-amber-900">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-amber-600" />
            What eWallet ZA Will NEVER Ask You For
          </CardTitle>
          <CardDescription>
            Be immediately suspicious if anyone asks for the following information:
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex gap-3 p-4 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-900">
              <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">Your full password or PIN</p>
                <p className="text-xs text-muted-foreground">No legitimate service will ever ask for your complete password</p>
              </div>
            </div>
            <div className="flex gap-3 p-4 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-900">
              <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">OTP (One-Time PIN) codes</p>
                <p className="text-xs text-muted-foreground">These are for your use only, never share them with anyone</p>
              </div>
            </div>
            <div className="flex gap-3 p-4 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-900">
              <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">Full debit/credit card details</p>
                <p className="text-xs text-muted-foreground">Including CVV, expiry date, and full card number</p>
              </div>
            </div>
            <div className="flex gap-3 p-4 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-900">
              <XCircle className="w-5 h-5 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">Remote access to your device</p>
                <p className="text-xs text-muted-foreground">Never install software or give screen access to unknown callers</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Password Security Best Practices */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-indigo-600" />
            Password Security Best Practices
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="flex gap-3 p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">Use a strong, unique password</p>
                <p className="text-xs text-muted-foreground">At least 12 characters with uppercase, lowercase, numbers, and symbols</p>
              </div>
            </div>
            <div className="flex gap-3 p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">Change your password regularly</p>
                <p className="text-xs text-muted-foreground">Update your password every 3-6 months for maximum security</p>
              </div>
            </div>
            <div className="flex gap-3 p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">Never reuse passwords</p>
                <p className="text-xs text-muted-foreground">Use different passwords for different accounts</p>
              </div>
            </div>
            <div className="flex gap-3 p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
              <CheckCircle2 className="w-5 h-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm mb-1">Use a password manager</p>
                <p className="text-xs text-muted-foreground">Store passwords securely instead of writing them down</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Common Scams in South Africa */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            Common Scams in South Africa
          </CardTitle>
          <CardDescription>
            Be aware of these common fraud tactics used to steal banking information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="phishing">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Phishing Emails & SMS (Smishing)
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 text-sm">
                <p>
                  <strong>What it is:</strong> Fraudulent emails or text messages that appear to be from eWallet ZA,
                  your bank, or services like SARS, asking you to click links or provide personal information.
                </p>
                <div className="bg-amber-50 dark:bg-amber-950/30 p-3 rounded border border-amber-200 dark:border-amber-900">
                  <p className="text-xs mb-2">Common examples in South Africa:</p>
                  <ul className="text-xs space-y-1 list-disc list-inside">
                    <li>"Your SASSA grant is pending - click here to verify"</li>
                    <li>"eWallet ZA account suspended - update your details"</li>
                    <li>"You've won a Shoprite voucher - claim now"</li>
                    <li>"SARS tax refund awaiting - verify your bank details"</li>
                  </ul>
                </div>
                <p>
                  <strong>How to protect yourself:</strong> Never click links in unexpected messages. Always access
                  your account directly through our official website or app.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="vishing">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Vishing (Voice Phishing) Calls
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 text-sm">
                <p>
                  <strong>What it is:</strong> Scammers call pretending to be from eWallet ZA, your bank, or
                  government agencies, creating urgency to trick you into revealing sensitive information.
                </p>
                <div className="bg-amber-50 dark:bg-amber-950/30 p-3 rounded border border-amber-200 dark:border-amber-900">
                  <p className="text-xs mb-2">Red flags to watch for:</p>
                  <ul className="text-xs space-y-1 list-disc list-inside">
                    <li>Caller claims your account will be closed unless you act immediately</li>
                    <li>Asks for your password, PIN, or OTP code</li>
                    <li>Requests remote access to your phone or computer</li>
                    <li>Pressures you to make immediate payments or transfers</li>
                  </ul>
                </div>
                <p>
                  <strong>How to protect yourself:</strong> Hang up and call eWallet ZA directly using the number
                  on our official website. Never give out sensitive information over the phone.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="sim-swap">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  SIM Swap Fraud
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 text-sm">
                <p>
                  <strong>What it is:</strong> Criminals obtain your personal information and convince your mobile
                  provider to transfer your number to a new SIM card, allowing them to receive your OTP codes.
                </p>
                <div className="bg-amber-50 dark:bg-amber-950/30 p-3 rounded border border-amber-200 dark:border-amber-900">
                  <p className="text-xs mb-2">Warning signs:</p>
                  <ul className="text-xs space-y-1 list-disc list-inside">
                    <li>Your phone suddenly has no signal or network</li>
                    <li>You receive notifications about SIM changes you didn't request</li>
                    <li>You can't make calls or send messages unexpectedly</li>
                  </ul>
                </div>
                <p>
                  <strong>How to protect yourself:</strong> Contact your mobile provider immediately if you lose
                  signal unexpectedly. Set up additional PINs with your network provider. Monitor your accounts regularly.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="social-engineering">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <UserX className="w-4 h-4" />
                  Social Engineering
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 text-sm">
                <p>
                  <strong>What it is:</strong> Manipulating people into revealing confidential information by
                  building trust or creating fear. This can happen online, over the phone, or in person.
                </p>
                <div className="bg-amber-50 dark:bg-amber-950/30 p-3 rounded border border-amber-200 dark:border-amber-900">
                  <p className="text-xs mb-2">Common tactics:</p>
                  <ul className="text-xs space-y-1 list-disc list-inside">
                    <li>Pretending to be IT support needing your password to "fix" an issue</li>
                    <li>Creating fake social media profiles to gain your trust</li>
                    <li>Impersonating friends or family in distress needing money urgently</li>
                    <li>Offering jobs or business opportunities that require upfront payments</li>
                  </ul>
                </div>
                <p>
                  <strong>How to protect yourself:</strong> Always verify the identity of anyone requesting
                  sensitive information. When in doubt, contact the organization directly using official channels.
                </p>
              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="fake-apps">
              <AccordionTrigger>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Fake Apps & Websites
                </div>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 text-sm">
                <p>
                  <strong>What it is:</strong> Counterfeit mobile apps or websites designed to look like
                  legitimate banking platforms to steal your login credentials and personal information.
                </p>
                <div className="bg-amber-50 dark:bg-amber-950/30 p-3 rounded border border-amber-200 dark:border-amber-900">
                  <p className="text-xs mb-2">How to identify fake apps/sites:</p>
                  <ul className="text-xs space-y-1 list-disc list-inside">
                    <li>Check the exact URL - scammers use similar-looking domain names</li>
                    <li>Look for spelling mistakes or poor quality graphics</li>
                    <li>Verify the app publisher name in the app store</li>
                    <li>Be wary of apps requesting excessive permissions</li>
                  </ul>
                </div>
                <p>
                  <strong>How to protect yourself:</strong> Only download apps from official app stores.
                  Bookmark our official website (www.ewallet.co.za) and always check the URL before logging in.
                </p>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>

      {/* Security Checklist */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-600" />
            Your Security Checklist
          </CardTitle>
          <CardDescription>
            Follow these essential practices to keep your account secure
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <Key className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm">Enable Two-Factor Authentication (2FA)</p>
                <p className="text-xs text-muted-foreground">Add an extra layer of security to your account</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <Eye className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm">Monitor your account regularly</p>
                <p className="text-xs text-muted-foreground">Check for unauthorized transactions and report them immediately</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <Lock className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm">Use secure networks only</p>
                <p className="text-xs text-muted-foreground">Avoid accessing your account on public Wi-Fi without a VPN</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm">Keep your devices updated</p>
                <p className="text-xs text-muted-foreground">Install security updates and use antivirus software</p>
              </div>
            </div>
            <div className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
              <Info className="w-5 h-5 text-indigo-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm">Be cautious with personal information</p>
                <p className="text-xs text-muted-foreground">Don't share banking details on social media or unsecured platforms</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* If You've Been Scammed */}
      <Card className="border-red-200 dark:border-red-900">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-400">
            <AlertTriangle className="w-5 h-5" />
            If You Suspect Fraud or Have Been Scammed
          </CardTitle>
          <CardDescription>
            Take immediate action to protect your account and minimize damage
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <Badge variant="destructive" className="mt-0.5">1</Badge>
              <div>
                <p className="text-sm">Contact eWallet ZA immediately on our official support line</p>
                <p className="text-xs text-muted-foreground">We'll freeze your account to prevent further unauthorized access</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="destructive" className="mt-0.5">2</Badge>
              <div>
                <p className="text-sm">Change your password and PIN immediately</p>
                <p className="text-xs text-muted-foreground">Use a completely new password you've never used before</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="destructive" className="mt-0.5">3</Badge>
              <div>
                <p className="text-sm">Report the incident to the South African Police Service (SAPS)</p>
                <p className="text-xs text-muted-foreground">File a case at your nearest police station and keep the case number</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="destructive" className="mt-0.5">4</Badge>
              <div>
                <p className="text-sm">Contact your bank if linked cards were compromised</p>
                <p className="text-xs text-muted-foreground">Request card cancellation and dispute any fraudulent transactions</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Badge variant="destructive" className="mt-0.5">5</Badge>
              <div>
                <p className="text-sm">Report to the South African Banking Risk Information Centre (SABRIC)</p>
                <p className="text-xs text-muted-foreground">Visit www.sabric.co.za or call 0860 123 000</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Contact Information */}
      <Card className="bg-indigo-50 dark:bg-indigo-950/30 border-indigo-200 dark:border-indigo-900">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-600" />
            Official Contact Information
          </CardTitle>
          <CardDescription>
            Only use these verified channels to contact eWallet ZA
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center gap-3">
            <Phone className="w-4 h-4 text-indigo-600" />
            <div>
              <p className="text-sm">24/7 Support Hotline</p>
              <p className="text-sm">0860 EWALLET (0860 392 5538)</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Mail className="w-4 h-4 text-indigo-600" />
            <div>
              <p className="text-sm">Email Support</p>
              <p className="text-sm">security@ewallet.co.za</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Shield className="w-4 h-4 text-indigo-600" />
            <div>
              <p className="text-sm">Official Website</p>
              <p className="text-sm">www.ewallet.co.za</p>
            </div>
          </div>
          <div className="mt-4 p-3 bg-white dark:bg-gray-900 rounded border border-indigo-300 dark:border-indigo-800">
            <p className="text-xs text-muted-foreground">
              <strong>Remember:</strong> eWallet ZA will never ask you to provide your password, PIN, or OTP
              via email, SMS, or phone. If someone claiming to be from eWallet ZA requests this information,
              it is a scam. Hang up and contact us immediately through our official channels.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
