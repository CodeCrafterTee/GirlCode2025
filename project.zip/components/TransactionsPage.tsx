import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Search, Filter, ArrowLeftRight, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

export function TransactionsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Transactions</h1>
        <p className="text-gray-600 dark:text-gray-400">View and manage your transaction history</p>
      </div>

      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>No Transactions Yet</AlertTitle>
        <AlertDescription>
          Once you start using your account, all your transactions will be displayed here. You'll be able to search, filter, and download your transaction history.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>Search and filter your transactions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search transactions..."
                className="pl-10"
                disabled
              />
            </div>
            <Button variant="outline" disabled>
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
          </div>

          <div className="text-center py-16">
            <div className="mx-auto w-20 h-20 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mb-4">
              <ArrowLeftRight className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-lg mb-2">No Transactions</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm max-w-md mx-auto">
              Your transaction history is empty. Start by adding funds to your account or making your first payment.
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Total Spent</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl text-gray-400">R0.00</p>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Total Received</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl text-gray-400">R0.00</p>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Total Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl text-gray-400">0</p>
            <p className="text-xs text-gray-500 mt-1">This month</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
